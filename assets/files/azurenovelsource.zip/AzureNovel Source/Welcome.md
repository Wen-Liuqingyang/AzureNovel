---
title: 欢迎来到 Azure Novel！
icon: sparkle
authors: 
- name: 文柳轻扬
  email: wen-liuqingyang@outlook.com
  avatar: Assets/avatar.jpg
order: 10000
---

# 欢迎来到 Azure Novel！

在这里，有我写的所有小说，但大部分是《蔚蓝档案》的同人~

当然，为了使世界观更加完整，这里会出现包括但不限于《明日方舟》、《明日方舟：终末地》等其它作品的设定。

《蔚蓝 • 爱与奇迹的回响》是由 **凌泽穆宇** 同志创作的同人。

在看小说前建议先阅读更新日志，了解最新的更新内容和进度哦~

点击下面的连接可以下载此网站完整源码，也可以在本地运行，体验更快的访问速度(仅限PC)。
[!file](/static/sample.txt)